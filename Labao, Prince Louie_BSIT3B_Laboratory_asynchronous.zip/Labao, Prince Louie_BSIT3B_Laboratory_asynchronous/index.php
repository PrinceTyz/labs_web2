<?php
require_once("config/dbcon.php");

$sql = "SELECT * FROM customer_data";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Data</title>
</head>
<body>
</div>


        <h1 style="color: black;">Customer Data</h1>
        <hr>
    </div> 
    <a href="add.php">Add Data</a> 
    </div>
        <table class="table table-bordered">
                <tr  style="background: yellow;">
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th class="text-center">Address</th>
                    <th>Order ID</th>
                    <th>Order Name</th>
                    <th>Price of Order</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["first_name"] . "</td>";
                        echo "<td>" . $row["middle_name"] . "</td>";
                        echo "<td>" . $row["last_name"] . "</td>";
                        echo "<td>" . $row["date_of_birth"] . "</td>";
                        echo "<td>" . $row["gender"] . "</td>";
                        echo "<td>" . $row["age"] . "</td>";
                        echo "<td>" . $row["address_loc"] . "</td>";
                        echo "<td>" . $row["order_id"] . "</td>";
                        echo "<td>" . $row["order_name"] . "</td>";
                        echo "<td>" . $row["price"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='11'>No data available</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

 

</body>
</html>
<style>
    body{
    background: linear-gradient(to left, #ade5d3, #38bddf);
      background-attachment: fixed; 
      margin: 0; 
      padding: 0;
    } 
    
    table {
    margin-top: 30px;    
    width: 100%;
    border-collapse: collapse;
    }

    table, th, td {
        border: 1px solid #ccc;
    }

    th, td {
        padding: 8px;
        text-align: left;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #ddd;
    }

    th {
        background-color: yellow;
        text-align: center;
    }

    a {
      
      text-decoration: none;
      background-color: black;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 3px;
      font-size: 16px;
      cursor: pointer;
      margin-left: 50px;
    
    }
    h1{
        text-align: center;
    }
</style>
