<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<div class="container">
    <h1 class="text-center">CUSTOMER</h1>
    <form action="function.php" method="post">
        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" required><br><br>
        
        <label for="middle_name">Middle Name:</label>
        <input type="text" name="middle_name"><br><br>

        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" required><br><br>
    
        
        <label for="date_of_birth">Date of Birth:</label>
        <input type="date" name="date_of_birth" required><br><br>
        
        <label for="gender">Gender:</label>
        <select name="gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br><br>
        
        <label for="age">Age:</label>
        <input type="number" name="age" required><br><br>
        
        <label for="address">Complete Address:</label>
        <textarea name="address_loc" required></textarea><br><br>
        
        <label for="order_id">Order ID:</label>
        <input type="text" name="order_id" required><br><br>
        
        <label for="order_name">Order Name:</label>
        <input type="text" name="order_name" required><br><br>
        
        <label for="price">Price of Order:</label>
        <input type="number" step="0.01" name="price" required><br><br>
        
        <input type="submit" value="Submit">
    </form>
</div>
</body>
</html>
<style>
 body {
      font-family: Arial, sans-serif;
      background: linear-gradient(to left, #ade5d3, #38bddf);
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 350px;
      margin: 0 auto;
      padding: 10px;
      background-color: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      border-radius: 5px;
    }

    h1 {
      text-align: center;
      font-size: 24px;
    }

    label {
      display: block;
      margin-bottom: 1px;
      font-size: 16px;
      margin-left: 50px;
    }

    input[type="text"],
    input[type="number"],
    select,
    textarea {
      width: 50%;
      padding: 5px;
      margin-bottom: 5px;
      margin-left: 50px;
      border: 1px solid #ccc;
      border-radius: 3px;
      font-size: 16px;
    }

    select {
      height: 40px;
      
    }

    textarea {
      height: 100px;
    }

    input[type="submit"] {
      background-color: #007BFF;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 3px;
      font-size: 16px;
      cursor: pointer;
      margin-left: 100px;
    }

    input[type="submit"]:hover {
      background-color: #0056b3;
    }
 
    input[type="date"] {
    width: 50%;
    padding: 8px;
    margin-bottom: 10px;
    margin-left: 50px;
    border: 1px solid #ccc;
    border-radius: 3px;
    font-size: 14px;
    }
    label[for="date_of_birth"] {
    font-size: 14px;
    margin-bottom: 5px;
  
}

</style>