<?php
require_once("config/dbcon.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST["first_name"];
    $middle_name = $_POST["middle_name"];
    $last_name = $_POST["last_name"];
    $date_of_birth = $_POST["date_of_birth"];
    $gender = $_POST["gender"];
    $age = $_POST["age"];
    $address = $_POST["address_loc"];
    $order_id = $_POST["order_id"];
    $order_name = $_POST["order_name"];
    $price = $_POST["price"];

    $sql = "INSERT INTO customer_data (first_name, middle_name, last_name, date_of_birth, gender, age, address_loc, order_id, order_name, price) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssisisd", $first_name, $middle_name, $last_name, $date_of_birth, $gender, $age, $address, $order_id, $order_name, $price);
    
    if ($stmt->execute()) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
