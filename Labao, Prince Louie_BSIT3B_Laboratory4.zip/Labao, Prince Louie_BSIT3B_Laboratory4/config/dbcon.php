<?php
$servername = "localhost"; 
$username = "root";
$password = "";
$dbname = "info_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Variables to hold form data
$Fname = $Mname = $Lname = $Studno = $Pname = $Pcont = "";

if(isset($_POST['submit'])) {
    // Sanitize and validate data (add appropriate validation)

    $Fname = mysqli_real_escape_string($conn, $_POST['Fname']);
    $Mname = mysqli_real_escape_string($conn, $_POST['Mname']);
    $Lname = mysqli_real_escape_string($conn, $_POST['Lname']);
    $Studno = mysqli_real_escape_string($conn, $_POST['Studno']);
    $Pname = mysqli_real_escape_string($conn, $_POST['Pname']);
    $Pcont = mysqli_real_escape_string($conn, $_POST['Pcont']);

    // SQL query
    $sql = "INSERT INTO `info_form` (`Fname`, `Mname`, `Lname`, `Studno`, `Pname`, `Pcont`) 
            VALUES ('$Fname', '$Mname', '$Lname', '$Studno', '$Pname', '$Pcont')";

    if (mysqli_query($conn, $sql)) {
        header("location: index.php?msg=New record created successfully");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
